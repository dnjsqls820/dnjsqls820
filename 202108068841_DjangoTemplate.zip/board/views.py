from django.shortcuts import render

# Create your views here.

def home(request):

    context = {}

    context['title'] = '장고 홈페이지'

    return render(request, 'home.html', context)